<?php

header("Location: ./page/");