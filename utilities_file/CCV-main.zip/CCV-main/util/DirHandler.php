<?php

class DirHandler
{
    public $admin_profile = "../assets/img/profile/admin/";
    public $counselor_profile = "../assets/img/profile/counselor/";
    public $counselor_license = "../assets/img/license/counselor_license/";
    public $youth_leader = "../assets/img/profile/youth_leader/";
    public $lawyer_license = "../assets/img/license/lawyer/";
    public $users_profile = "../assets/img/profile/users/";
    public $lhp_profile = "../assets/img/profile/lhp_profile/";
    public $livelihood_provider_license = "../assets/img/license/livelihood_provider_license/";
}
