<div class="sidebar" id="mySidebar">
    <div class="side-header">
        <h5 style="color: #A153A0; margin-top: 10px; font-weight: bold;">Hello, Lawyer</h5>
    </div>

    <hr style="border: 1px solid; background-color: #FFC0CB; border-color: #3B3131;">
    
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="../lawyer/index.php"><i class="menu-icon fa fa-home"></i> Dashboard</a>
    <a href="../lawyer/dashboard.php" onclick="showBookings()"><i class="fa fa-users"></i> Bookings</a>
    <a href="../lawyer/previous.book.php" onclick="showCategory()"><i class="fa fa fa-users"></i> Previous Bookings</a>
</div>

<div id="main">
    <button class="openbtn" onclick="openNav()"><i class="menu-icon fa fa-bars"></i></button>
</div>