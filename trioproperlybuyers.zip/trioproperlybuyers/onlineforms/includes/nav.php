<!--nav-->



<div id="nav">
	<div class="container">
		<div class="page-nav dropdown">
			<ul>
				<li class="<?php echo $a;?>"><a href="panel.php">CHECK MAIL</a></li>
				<li class="navspacer"></li>
				<li class=""><a id="deletemarked" href="javascript:;">DELETE</a></li>	
				<li class="navspacer"></li>	
				<li class="<?php echo $c;?>"><a id="print" href="javascript:;">PRINT</a></li>
				<li class="navspacer"></li>
				<li class="<?php echo $c;?>"><a id="convert" href="javascript:;">CONVERT TO PDF FILE</a></li>
				<li class="navspacer"></li>							
				<li class="<?php echo $d;?>" id="last"><a id="trigger-menu" href="javascript:;">MORE</a></li>
				<div class="drop-menu" style="display:none;">
					<a id="markedread" class="read">Mark as Read</a>
					<a id="markednew" class="new">Mark as New</a>
				</div>
			</ul>
		</div>
	</div>
</div>



<!-- <nav>  
	<div class="container clearfix">
		<div class="page-nav dropdown">
			<ul>
				<li class="index.php"><a href="">CHECK MAIL</a></li>
				<li><a href="">DELETE</a></li>
				<li><a href="">PRINT</a></li>
				<li><a href="">MORE</a></li>
				
			</ul>
		</div>
	</div>
</nav> -->



